Purisa.ttf is a font, that is not available on 
Windows by default. The soulmate.py code example uses
this font. Install the font by clicking on it.

The code examples were tested on Linux and Windows. 
Python 3.6.2 and PyQt5 5.9.1 on Windows 7 and
Python 3.5.2 and PyQt 5.9.1 on Debian Linux.

